#!/usr/bin/env python3
"""
SQLite MCP Server for querying database at ./data/healthcare_sample.sqlite
"""

import asyncio
import json
import sqlite3
import sys
from typing import Any, Dict, List

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

DB_PATH = "./data/healthcare_sample.sqlite"

class SQLiteMCPServer:
    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self.server = Server("sqlite-query-server")
        self.setup_tools()

    def setup_tools(self):
        @self.server.list_tools()
        async def list_tools() -> List[Tool]:
            return [
                Tool(
                    name="query_sqlite",
                    description="Execute SQL queries on the SQLite database.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "query": {"type": "string", "description": "The SQL query to execute"},
                            "fetch_all": {"type": "boolean", "description": "Fetch all results?", "default": True}
                        },
                        "required": ["query"]
                    }
                )
            ]

        @self.server.call_tool()
        async def call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
            if name == "query_sqlite":
                return await self._execute_query(arguments)
            else:
                raise ValueError(f"Unknown tool: {name}")

    async def _execute_query(self, arguments: Dict[str, Any]) -> List[TextContent]:
        query = arguments.get("query", "")
        fetch_all = arguments.get("fetch_all", True)
        if not query:
            return [TextContent(type="text", text="Error: No query provided")]
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute(query)
            if query.strip().upper().startswith(("SELECT", "PRAGMA")):
                if fetch_all:
                    results = cursor.fetchall()
                else:
                    results = cursor.fetchone()
                    results = [results] if results else []
                if results:
                    data = [dict(row) for row in results]
                    result_text = json.dumps(data, indent=2, default=str)
                else:
                    result_text = "No results found"
            else:
                conn.commit()
                result_text = f"Query executed successfully. Rows affected: {cursor.rowcount}"
            conn.close()
            return [TextContent(type="text", text=result_text)]
        except sqlite3.Error as e:
            return [TextContent(type="text", text=f"SQLite error: {str(e)}")]
        except Exception as e:
            return [TextContent(type="text", text=f"Error: {str(e)}")]

    async def run(self):
        async with stdio_server() as (read_stream, write_stream):
            await self.server.run(read_stream, write_stream, self.server.create_initialization_options())

async def main():
    server = SQLiteMCPServer()
    await server.run()

if __name__ == "__main__":
    asyncio.run(main())
