# main.py

from mcp_integration import McpServerIntegration
from utils.db_simulator import setup_sample_db, get_db_schema

setup_sample_db()  # Optional if DB is already initialized

inputs = {
    "user_input": "Show me the top 5 products by total revenue for April 2024",
    "db_schema": get_db_schema("data/sample_db.sqlite")
}

try:
    integration = McpServerIntegration()
    crew = integration.crew()
    result = crew.kickoff(inputs=inputs)
    print("\n✅ Execution Complete")
    print("Reviewed SQL:\n", result.get('reviewed_sqlquery'))
    print("Compliance Report:\n", result.get('report'))
    print("Query Result:\n", result.get('result'))
finally:
    integration.stop()
