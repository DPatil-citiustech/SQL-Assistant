# ✅ app.py
import streamlit as st
from crew_setup import sql_generator_crew, sql_reviewer_crew, sql_compliance_crew, sql_executor_crew
from utils.db_simulator import get_structured_schema, run_query
from utils.helper import extract_token_counts, calculate_gpt4o_cost
from utils.approved_cache import load_approved_prompts, save_approved_prompt, search_approved_prompts
import sqlparse

DB_PATH = "data/healthcare_sample.sqlite"

@st.cache_data(show_spinner=False)
def load_schema():
    return get_structured_schema(DB_PATH)

st.title("SQL Assistant Crew")

st.markdown("""
Welcome to the SQL Assistant Crew!  
This app lets you interact with your database using natural language. Simply type your data question or request and our multi-agent system will:

1. **Generate** a relevant SQL query
2. **Review** and optimize the query
3. **Check** for compliance and safety
4. **Execute** the query (if compliant)

This tool is perfect for business users, analysts, and anyone who wants to query data without writing SQL by hand!
""")

if st.button("Refresh Schema"):
    load_schema.clear()
    st.success("Schema refreshed from database.")

db_schema = load_schema()

with st.expander("Show database schema"):
    st.code(db_schema)

st.subheader("\U0001F4CB Approved Prompts History")
search_input = st.text_input("Search approved prompts (optional)")
if search_input.strip():
    approved = search_approved_prompts(search_input.strip())
else:
    approved = load_approved_prompts()

if approved:
    for i, (prompt, sql) in enumerate(approved.items(), 1):
        with st.expander(f"{i}. {prompt}"):
            st.code(sql, language="sql")
else:
    st.info("No approved prompts found yet.")

if "generated_sql" not in st.session_state:
    st.session_state["generated_sql"] = None
if "awaiting_confirmation" not in st.session_state:
    st.session_state["awaiting_confirmation"] = False
if "reviewed_sql" not in st.session_state:
    st.session_state["reviewed_sql"] = None
if "compliance_report" not in st.session_state:
    st.session_state["compliance_report"] = None
if "query_result" not in st.session_state:
    st.session_state["query_result"] = None
if "regenerate_sql" not in st.session_state:
    st.session_state["regenerate_sql"] = False
if "llm_cost" not in st.session_state:
    st.session_state["llm_cost"] = 0.0

user_prompt = st.text_input("Enter your request:")

if st.session_state.get("regenerate_sql"):
    if user_prompt.strip():
        try:
            if user_prompt in load_approved_prompts():
                st.session_state["generated_sql"] = load_approved_prompts()[user_prompt]
                st.session_state["awaiting_confirmation"] = True
                st.success("\u2705 Retrieved SQL from approved list — no LLM call needed.")
            else:
                gen_output = sql_generator_crew.kickoff(inputs={"user_input": user_prompt, "db_schema": db_schema})
                raw_sql = gen_output.pydantic.sqlquery
                st.session_state["generated_sql"] = raw_sql
                st.session_state["awaiting_confirmation"] = True
                token_usage_str = str(gen_output.token_usage)
                prompt_tokens, completion_tokens = extract_token_counts(token_usage_str)
                cost = calculate_gpt4o_cost(prompt_tokens, completion_tokens)
                st.session_state["llm_cost"] += cost
        except Exception as e:
            st.error(f"An error occurred: {e}")
    else:
        st.warning("Please enter a prompt.")
    st.session_state["regenerate_sql"] = False

if st.button("Generate SQL"):
    if user_prompt.strip():
        try:
            if user_prompt in load_approved_prompts():
                st.session_state["generated_sql"] = load_approved_prompts()[user_prompt]
                st.session_state["awaiting_confirmation"] = True
                st.success("\u2705 Retrieved SQL from approved list — no LLM call needed.")
            else:
                gen_output = sql_generator_crew.kickoff(inputs={"user_input": user_prompt, "db_schema": db_schema})
                raw_sql = gen_output.pydantic.sqlquery
                st.session_state["generated_sql"] = raw_sql
                st.session_state["awaiting_confirmation"] = True
                token_usage_str = str(gen_output.token_usage)
                prompt_tokens, completion_tokens = extract_token_counts(token_usage_str)
                cost = calculate_gpt4o_cost(prompt_tokens, completion_tokens)
                st.session_state["llm_cost"] += cost
        except Exception as e:
            st.error(f"An error occurred: {e}")
    else:
        st.warning("Please enter a prompt.")

if st.session_state.get("awaiting_confirmation") and st.session_state.get("generated_sql"):
    st.subheader("Generated SQL")
    formatted_generated_sql = sqlparse.format(st.session_state["generated_sql"], reindent=True, keyword_case='upper')
    st.code(formatted_generated_sql, language="sql")
    st.info(f"Your LLM cost so far: ${st.session_state['llm_cost']:.6f}")
    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("Confirm and Review"):
            try:
                review_output = sql_reviewer_crew.kickoff(inputs={"sql_query": st.session_state["generated_sql"],"db_schema": db_schema})
                reviewed_sql = review_output.pydantic.reviewed_sqlquery
                st.session_state["reviewed_sql"] = reviewed_sql
                token_usage_str = str(review_output.token_usage)
                prompt_tokens, completion_tokens = extract_token_counts(token_usage_str)
                cost = calculate_gpt4o_cost(prompt_tokens, completion_tokens)
                st.session_state["llm_cost"] += cost
                compliance_output = sql_compliance_crew.kickoff(inputs={"reviewed_sqlquery": reviewed_sql})
                compliance_report = compliance_output.pydantic.report
                token_usage_str = str(compliance_output.token_usage)
                prompt_tokens, completion_tokens = extract_token_counts(token_usage_str)
                cost = calculate_gpt4o_cost(prompt_tokens, completion_tokens)
                st.session_state["llm_cost"] += cost
                lines = compliance_report.splitlines()
                if lines and lines[0].strip().lower().startswith("# compliance report"):
                    compliance_report = "\n".join(lines[1:]).lstrip()
                st.session_state["compliance_report"] = compliance_report
                if "compliant" in compliance_report.lower():
                    result = run_query(reviewed_sql)
                    st.session_state["query_result"] = result
                    save_approved_prompt(user_prompt, reviewed_sql)
                else:
                    st.session_state["query_result"] = None
                st.session_state["awaiting_confirmation"] = False
                st.rerun()
            except Exception as e:
                st.error(f"An error occurred: {e}")
    with col2:
        if st.button("Try Again"):
            st.session_state["generated_sql"] = None
            st.session_state["awaiting_confirmation"] = False
            st.session_state["reviewed_sql"] = None
            st.session_state["compliance_report"] = None
            st.session_state["query_result"] = None
            st.session_state["regenerate_sql"] = True
            st.rerun()
    with col3:
        if st.button("Abort"):
            st.session_state.clear()
            st.rerun()

elif st.session_state.get("reviewed_sql"):
    st.subheader("Reviewed SQL")
    formatted_sql = sqlparse.format(st.session_state["reviewed_sql"], reindent=True, keyword_case='upper')
    st.code(formatted_sql, language="sql")
    st.subheader("Compliance Report")
    st.markdown(st.session_state["compliance_report"])
    if st.session_state.get("query_result"):
        st.subheader("Query Result")
        st.code(st.session_state["query_result"])
    st.info(f"Your LLM cost so far: ${st.session_state['llm_cost']:.6f}")
