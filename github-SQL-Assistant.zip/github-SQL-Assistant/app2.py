# ✅ app.py
import streamlit as st
from crew_setup import sql_generator_crew, sql_reviewer_crew, sql_compliance_crew, sql_executor_crew
from utils.db_simulator import get_structured_schema, run_query
from utils.helper import extract_token_counts, calculate_gpt4o_cost
from utils.approved_cache import load_approved_prompts, save_approved_prompt, search_approved_prompts
import sqlparse

DB_PATH = "data/healthcare_sample.sqlite"

# Set page configuration
st.set_page_config(page_title="SQL Assistant Crew", layout="wide", initial_sidebar_state="collapsed")

# Enhanced modern UI styling with animations and professional design
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
    
    /* Main theme colors - enhanced palette */
    :root {
        --primary: #4361ee;
        --primary-hover: #3a56d4;
        --secondary: #4cc9f0;
        --surface: #FFFFFF;
        --background: #f8fafc;
        --text: #0f172a;
        --text-light: #64748b;
        --success: #10b981;
        --warning: #f59e0b;
        --error: #ef4444;
        --border: #e2e8f0;
        --accent: #8b5cf6;
        --gray-50: #f9fafb;
        --gray-100: #f3f4f6;
        --gray-200: #e5e7eb;
        --gray-300: #d1d5db;
    }

    /* Base styling */
    body {
        font-family: 'Inter', sans-serif;
        color: var(--text);
        background-color: var(--background);
    }
    
    .main {
        background-color: var(--background);
        padding: 0 !important;
    }
    
    /* Enhanced header styling with animated gradient */
    .header {
        background: linear-gradient(-45deg, #4361ee, #3a0ca3, #4cc9f0, #4361ee);
        background-size: 400% 400%;
        animation: gradient 15s ease infinite;
        color: white;
        padding: 1.25rem 1.5rem;
        border-radius: 0 0 12px 12px;
        margin-bottom: 1.5rem;
        box-shadow: 0 4px 12px rgba(59, 130, 246, 0.1);
    }
    
    @keyframes gradient {
        0% {
            background-position: 0% 50%;
        }
        50% {
            background-position: 100% 50%;
        }
        100% {
            background-position: 0% 50%;
        }
    }
    
    .header h1 {
        font-weight: 700 !important;
        margin: 0;
        color: white !important;
        font-size: 1.75rem !important;
        letter-spacing: -0.02em;
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    
    .header p {
        margin: 0.25rem 0 0 0;
        opacity: 0.9;
        font-size: 0.95rem;
        font-weight: 400;
    }
    
    /* Enhanced logo badge */
    .logo-badge {
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(255, 255, 255, 0.2);
        width: 48px;
        height: 48px;
        border-radius: 12px;
        margin-right: 0.85rem;
        backdrop-filter: blur(8px);
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        animation: pulse 3s infinite;
    }
    
    @keyframes pulse {
        0% {
            box-shadow: 0 0 0 0 rgba(255, 255, 255, 0.4);
        }
        70% {
            box-shadow: 0 0 0 10px rgba(255, 255, 255, 0);
        }
        100% {
            box-shadow: 0 0 0 0 rgba(255, 255, 255, 0);
        }
    }
    
    /* Enhanced content containers */
    .container {
        background-color: var(--surface);
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        transition: all 0.3s ease;
        border: 1px solid var(--gray-200);
    }
    
    .container:hover {
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.05);
    }
    
    /* Animation for new containers */
    .animate {
        animation: fadeIn 0.5s ease-out forwards;
    }
    
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    /* Modern process steps - FIX OVERLAPPING ISSUES */
    .steps-row {
        display: flex;
        gap: 0.75rem;
        margin: 1rem 0 1.25rem;
        flex-wrap: wrap; /* Allow wrapping on smaller screens */
    }
    
    .step-pill {
        flex: 1;
        min-width: 120px; /* Ensure minimum width */
        display: flex;
        align-items: center;
        padding: 0.85rem;
        border-radius: 8px;
        font-size: 0.85rem;
        font-weight: 500;
        transition: all 0.3s ease;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
        margin-bottom: 0.5rem; /* Add spacing when wrapped */
    }
    
    .step-pill:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.08);
    }
    
    .step-number {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 28px;
        height: 28px;
        border-radius: 50%;
        background-color: rgba(255, 255, 255, 0.25);
        font-size: 0.8rem;
        font-weight: 600;
        flex-shrink: 0;
        margin-right: 0.75rem;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    }
    
    .step-1 {
        background: linear-gradient(135deg, #4361ee, #3a56d4);
        color: white;
    }
    
    .step-2 {
        background: linear-gradient(135deg, #4cc9f0, #4895ef);
        color: white;
    }
    
    .step-3 {
        background: linear-gradient(135deg, #7209b7, #560bad);
        color: white;
    }
    
    .step-4 {
        background: linear-gradient(135deg, #f72585, #b5179e);
        color: white;
    }
    
    /* Headings */
    h2, h3, h4 {
        font-weight: 600 !important;
        color: var(--text);
        letter-spacing: -0.01em;
    }
    
    h2 {
        font-size: 1.25rem !important;
        margin-bottom: 1rem !important;
    }
    
    h3 {
        font-size: 1.1rem !important;
        margin-bottom: 0.75rem !important;
    }
    
    /* Enhanced pills and badges */
    .badge {
        display: inline-flex;
        align-items: center;
        padding: 0.35rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 500;
        margin: 0.35rem 0;
        transition: all 0.2s;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
    }
    
    .badge:hover {
        transform: translateY(-1px);
    }
    
    .badge.success {
        background-color: rgba(16, 185, 129, 0.1);
        color: #065F46;
        border: 1px solid rgba(16, 185, 129, 0.2);
    }
    
    .badge.warning {
        background-color: rgba(245, 158, 11, 0.1);
        color: #92400E;
        border: 1px solid rgba(245, 158, 11, 0.2);
    }
    
    .badge.error {
        background-color: rgba(239, 68, 68, 0.1);
        color: #991B1B;
        border: 1px solid rgba(239, 68, 68, 0.2);
    }
    
    .badge.info {
        background-color: rgba(79, 70, 229, 0.1);
        color: #3730A3;
        border: 1px solid rgba(79, 70, 229, 0.2);
    }
    
    /* Enhanced cost display */
    .cost-display {
        display: inline-flex;
        align-items: center;
        font-family: 'JetBrains Mono', monospace;
        padding: 0.35rem 0.75rem;
        background-color: var(--gray-50);
        border: 1px solid var(--gray-200);
        border-radius: 8px;
        font-size: 0.8rem;
        color: var(--text);
        font-weight: 500;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.02);
    }
    
    .cost-display::before {
        content: '💸';
        margin-right: 0.4rem;
    }
    
    /* Enhanced buttons */
    .stButton > button {
        border-radius: 8px !important;
        font-weight: 500 !important;
        padding: 0.4rem 1rem !important;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05) !important;
        transition: all 0.2s !important;
        font-size: 0.9rem !important;
        border: 1px solid transparent !important;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1) !important;
    }
    
    .stButton > button:active {
        transform: translateY(0px) !important;
    }
    
    /* Enhanced input fields */
    .stTextInput > div > div > input,
    .stTextArea > div > div > textarea {
        border-radius: 8px !important;
        border: 2px solid var(--gray-200) !important;
        padding: 0.75rem !important;
        font-size: 0.95rem !important;
        transition: all 0.2s !important;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.02) !important;
    }
    
    .stTextInput > div > div > input:focus,
    .stTextArea > div > div > textarea:focus {
        border-color: var(--primary) !important;
        box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.15) !important;
    }
    
    /* Enhanced code display */
    pre {
        border-radius: 8px !important;
        font-size: 0.85rem !important;
        font-family: 'JetBrains Mono', monospace !important;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05) !important;
    }
    
    .stCodeBlock > div {
        max-height: 400px !important;
        overflow-y: auto !important;
        border-radius: 8px !important;
    }
    
    /* Enhanced expander */
    .streamlit-expanderHeader {
        border-radius: 8px !important;
        border: 1px solid var(--gray-200) !important;
        background-color: var(--gray-50) !important;
        padding: 0.75rem 1rem !important;
        font-size: 0.9rem !important;
        font-weight: 500 !important;
        transition: all 0.2s !important;
    }
    
    .streamlit-expanderHeader:hover {
        background-color: var(--gray-100) !important;
    }
    
    /* Enhanced divider */
    .divider {
        height: 1px;
        background-color: var(--gray-200);
        margin: 1rem 0;
        opacity: 0.6;
    }
    
    /* Fix for standard Streamlit components */
    div.stButton > button[kind="primary"] {
        background-color: var(--primary) !important;
        border: 1px solid var(--primary-hover) !important;
    }
    
    div.stButton > button[kind="primary"]:hover {
        background-color: var(--primary-hover) !important;
    }
    
    div.stButton > button[kind="secondary"] {
        background-color: var(--gray-50) !important;
        border: 1px solid var(--gray-200) !important;
        color: var(--text) !important;
    }
    
    div.stButton > button[kind="secondary"]:hover {
        background-color: var(--gray-100) !important;
    }
    
    /* Enhanced footer */
    .footer {
        text-align: center;
        padding: 1.5rem 0 1rem;
        color: var(--text-light);
        font-size: 0.8rem;
        border-top: 1px solid var(--gray-200);
        margin-top: 1.5rem;
        background: var(--gray-50);
        border-radius: 0 0 12px 12px;
    }
    
    /* Enhanced tools area */
    .tools-row {
        display: flex;
        gap: 0.75rem;
        margin: 1rem 0;
    }
    
    .tool-btn {
        flex: 1;
        background-color: var(--gray-50);
        border-radius: 8px;
        padding: 0.85rem;
        font-size: 0.85rem;
        cursor: pointer;
        transition: all 0.2s;
        color: var(--text);
        text-align: center;
        border: 1px solid var(--gray-200);
        font-weight: 500;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.02);
    }
    
    .tool-btn:hover {
        background-color: var(--gray-100);
        transform: translateY(-2px);
        box-shadow: 0 3px 6px rgba(0, 0, 0, 0.05);
    }
    
    /* Fix tab styling */
    .stTabs [data-baseweb="tab-list"] {
        gap: 0.5rem;
        background-color: transparent !important;
        border-bottom: 1px solid var(--gray-200) !important;
        padding-bottom: 0.5rem !important;
    }
    
    .stTabs [data-baseweb="tab"] {
        height: 2.25rem;
        white-space: pre;
        background-color: var(--gray-50);
        border-radius: 8px;
        padding: 0.5rem 1rem;
        font-size: 0.85rem;
        font-weight: 500;
        border: 1px solid var(--gray-200) !important;
        transition: all 0.2s !important;
    }
    
    .stTabs [aria-selected="true"] {
        background-color: var(--primary) !important;
        color: white !important;
        border: 1px solid var(--primary-hover) !important;
    }
    
    .stTabs [aria-selected="false"]:hover {
        background-color: var(--gray-100) !important;
    }
    
    /* Cards */
    .card {
        border-radius: 12px;
        background-color: var(--surface);
        border: 1px solid var(--gray-200);
        padding: 1.25rem;
        margin: 0.75rem 0;
        transition: all 0.3s;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.03);
    }
    
    .card:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.05);
    }
    
    /* Glowing effect for primary actions */
    .glow-btn {
        animation: glow 2s infinite alternate;
    }
    
    @keyframes glow {
        0% {
            box-shadow: 0 0 5px rgba(67, 97, 238, 0.2);
        }
        100% {
            box-shadow: 0 0 20px rgba(67, 97, 238, 0.4);
        }
    }
    
    /* Result animations */
    .result-animation {
        animation: slideUp 0.6s ease-out forwards;
    }
    
    @keyframes slideUp {
        0% {
            opacity: 0;
            transform: translateY(20px);
        }
        100% {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    /* Success indicator */
    .success-indicator {
        width: 6px;
        height: 6px;
        background-color: var(--success);
        border-radius: 50%;
        display: inline-block;
        margin-right: 8px;
        position: relative;
    }
    
    .success-indicator::after {
        content: '';
        position: absolute;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background-color: rgba(16, 185, 129, 0.2);
        top: -3px;
        left: -3px;
        animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;
    }
    
    @keyframes ping {
        75%, 100% {
            transform: scale(2);
            opacity: 0;
        }
    }
    
    /* Data table */
    .dataframe {
        border-collapse: collapse;
        width: 100%;
        border-radius: 8px;
        overflow: hidden;
        font-size: 0.85rem;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
    }
    
    .dataframe th {
        background-color: var(--gray-100);
        color: var(--text);
        text-align: left;
        padding: 0.75rem 1rem;
        font-weight: 600;
        border-bottom: 1px solid var(--gray-200);
    }
    
    .dataframe td {
        padding: 0.75rem 1rem;
        border-bottom: 1px solid var(--gray-200);
    }
    
    .dataframe tr:last-child td {
        border-bottom: none;
    }
    
    .dataframe tr:nth-child(even) {
        background-color: var(--gray-50);
    }
    
    .dataframe tr:hover {
        background-color: rgba(79, 70, 229, 0.05);
    }
    
    /* SQL result table specific styling */
    .sql-result-table {
        font-family: 'JetBrains Mono', monospace !important;
        white-space: pre;
        font-size: 0.9rem;
        line-height: 1.5;
    }
    
    .sql-result-table table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .sql-result-table th, .sql-result-table td {
        padding: 8px 12px;
        text-align: left;
        border-bottom: 1px solid var(--gray-200);
    }
    
    .sql-result-table th {
        background-color: var(--gray-100);
        font-weight: 600;
    }
    
    .sql-result-table tr:nth-child(even) {
        background-color: var(--gray-50);
    }
</style>
""", unsafe_allow_html=True)

@st.cache_data(show_spinner=False)
def load_schema():
    return get_structured_schema(DB_PATH)

# Initialize session state
if "generated_sql" not in st.session_state:
    st.session_state["generated_sql"] = None
if "awaiting_confirmation" not in st.session_state:
    st.session_state["awaiting_confirmation"] = False
if "reviewed_sql" not in st.session_state:
    st.session_state["reviewed_sql"] = None
if "compliance_report" not in st.session_state:
    st.session_state["compliance_report"] = None
if "is_compliant" not in st.session_state:
    st.session_state["is_compliant"] = None
if "query_result" not in st.session_state:
    st.session_state["query_result"] = None
if "regenerate_sql" not in st.session_state:
    st.session_state["regenerate_sql"] = False
if "llm_cost" not in st.session_state:
    st.session_state["llm_cost"] = 0.0

# Enhanced animated header with modern design
st.markdown("""
<div class="header">
    <div style="display: flex; align-items: center;">
        <div class="logo-badge">
            <span style="font-size: 1.6rem;">⚡</span>
        </div>
        <div>
            <h1>SQL Assistant Crew</h1>
            <p>Transform natural language into powerful SQL queries</p>
        </div>
    </div>
</div>
""", unsafe_allow_html=True)

# Main container - modern card design
st.markdown('<div class="container animate">', unsafe_allow_html=True)

# Visually appealing process steps
st.markdown('<h2 style="margin-top: 0;">How It Works</h2>', unsafe_allow_html=True)

st.markdown("""
<div class="steps-row">
    <div class="step-pill step-1">
        <div class="step-number">1</div>
        <div>Generate SQL</div>
    </div>
    <div class="step-pill step-2">
        <div class="step-number">2</div>
        <div>Expert Review</div>
    </div>
    <div class="step-pill step-3">
        <div class="step-number">3</div>
        <div>Security Check</div>
    </div>
    <div class="step-pill step-4">
        <div class="step-number">4</div>
        <div>Execute & Analyze</div>
    </div>
</div>
""", unsafe_allow_html=True)

# Enhanced tools with modern design - FIX OVERLAPPING SECTIONS
col1, col2 = st.columns(2)
with col1:
    with st.expander("📋 Database Schema", expanded=False):
        db_schema = load_schema()
        st.code(db_schema, language="sql")
        if st.button("🔄 Refresh Schema", key="refresh_schema"):
            load_schema.clear()
            st.success("✅ Schema updated")

with col2:
    with st.expander("📚 Past Conversations", expanded=False):
        approved = load_approved_prompts()
        if approved:
            st.markdown('<div class="query-history-wrapper">', unsafe_allow_html=True)
            
            # Display all queries directly without filtering
            st.markdown('<div style="margin-top: 15px; margin-bottom: 10px;">Retrieve prompt from history:</div>', unsafe_allow_html=True)
            selected = st.selectbox("", [""] + list(approved.keys()), label_visibility="collapsed")
            if selected:
                st.code(approved[selected], language="sql")
                if st.button("📋 Use This Query", type="primary"):
                    st.session_state["generated_sql"] = approved[selected]
                    st.session_state["awaiting_confirmation"] = True
                    st.rerun()
            st.markdown('</div>', unsafe_allow_html=True)
        else:
            st.info("📝 No saved queries yet. Your approved queries will appear here.")
            
# Enhanced query input area
st.markdown('<div class="container animate">', unsafe_allow_html=True)
st.markdown('<h2 style="margin-top: 0;">Ask Your Question</h2>', unsafe_allow_html=True)

user_prompt = st.text_area("", height=80, placeholder="Example: Show me all female patients born after 1980 who have been diagnosed with hypertension", key="user_input")
col1, col2 = st.columns([4, 1])
with col2:
    generate_btn = st.button("🚀 Generate SQL", type="primary", use_container_width=True, key="generate_btn")
    
    # Add subtle glow effect to the primary button
    st.markdown("""
    <script>
        const btn = document.querySelector('[data-testid="stButton"] button');
        btn.classList.add('glow-btn');
    </script>
    """, unsafe_allow_html=True)

if generate_btn or st.session_state.get("regenerate_sql"):
    if user_prompt.strip():
        try:
            if user_prompt in load_approved_prompts():
                st.session_state["generated_sql"] = load_approved_prompts()[user_prompt]
                st.session_state["awaiting_confirmation"] = True
                st.markdown('<div class="badge success">✅ Retrieved from approved queries</div>', unsafe_allow_html=True)
            else:
                with st.spinner("🧠 Generating SQL query..."):
                    gen_output = sql_generator_crew.kickoff(inputs={"user_input": user_prompt, "db_schema": db_schema})
                    raw_sql = gen_output.pydantic.sqlquery
                    st.session_state["generated_sql"] = raw_sql
                    st.session_state["awaiting_confirmation"] = True
                    token_usage_str = str(gen_output.token_usage)
                    prompt_tokens, completion_tokens = extract_token_counts(token_usage_str)
                    cost = calculate_gpt4o_cost(prompt_tokens, completion_tokens)
                    st.session_state["llm_cost"] += cost
        except Exception as e:
            st.error(f"Error: {e}")
    else:
        st.warning("⚠️ Please enter a question to generate SQL")
    st.session_state["regenerate_sql"] = False
st.markdown('</div>', unsafe_allow_html=True)

# Enhanced display for generated SQL and actions
if st.session_state.get("awaiting_confirmation") and st.session_state.get("generated_sql"):
    st.markdown('<div class="container animate">', unsafe_allow_html=True)
    st.markdown("""
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <h2 style="margin: 0; display: flex; align-items: center;">
            <div class="success-indicator"></div>
            Generated SQL
        </h2>
        <div class="cost-display">${:.6f}</div>
    </div>
    """.format(st.session_state["llm_cost"]), unsafe_allow_html=True)
    
    formatted_sql = sqlparse.format(st.session_state["generated_sql"], reindent=True, keyword_case='upper')
    st.code(formatted_sql, language="sql")
    
    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    
    # Fix button layout to prevent overflow
    col1, col2, col3 = st.columns([1, 1, 1])
    with col1:
        if st.button("✅ Approve & Execute Query", type="primary", use_container_width=True):
            try:
                with st.spinner("🔍 Expert reviewing query..."):
                    review_output = sql_reviewer_crew.kickoff(inputs={"sql_query": st.session_state["generated_sql"], "db_schema": db_schema})
                    reviewed_sql = review_output.pydantic.reviewed_sqlquery
                    st.session_state["reviewed_sql"] = reviewed_sql
                    token_usage_str = str(review_output.token_usage)
                    prompt_tokens, completion_tokens = extract_token_counts(token_usage_str)
                    cost = calculate_gpt4o_cost(prompt_tokens, completion_tokens)
                    st.session_state["llm_cost"] += cost

                with st.spinner("🛡️ Checking compliance..."):
                    compliance_output = sql_compliance_crew.kickoff(inputs={"reviewed_sqlquery": reviewed_sql})
                    compliance_report = compliance_output.pydantic.report
                    is_compliant = compliance_output.pydantic.is_compliant
                    token_usage_str = str(compliance_output.token_usage)
                    prompt_tokens, completion_tokens = extract_token_counts(token_usage_str)
                    cost = calculate_gpt4o_cost(prompt_tokens, completion_tokens)
                    st.session_state["llm_cost"] += cost
                    lines = compliance_report.splitlines()
                    if lines and lines[0].strip().lower().startswith("# compliance report"):
                        compliance_report = "\n".join(lines[1:]).lstrip()
                    st.session_state["compliance_report"] = compliance_report
                
                # Check if the report explicitly indicates the query is compliant
                # Look for "Verdict: Compliant" or similar patterns at the beginning of the report
                # Use the is_compliant boolean directly from the compliance crew output
                if is_compliant:
                    with st.spinner("⚙️ Executing query..."):
                        result = run_query(reviewed_sql)
                        st.session_state["query_result"] = result
                        save_approved_prompt(user_prompt, reviewed_sql)
                else:
                    st.session_state["query_result"] = None

                st.session_state["awaiting_confirmation"] = False
                st.rerun()
            except Exception as e:
                st.error(f"Error: {e}")
    with col2:
        if st.button("🔄 Regenerate", use_container_width=True):
            st.session_state["generated_sql"] = None
            st.session_state["awaiting_confirmation"] = False
            st.session_state["reviewed_sql"] = None 
            st.session_state["compliance_report"] = None
            st.session_state["query_result"] = None
            st.session_state["regenerate_sql"] = True
            st.rerun()
    with col3:
        if st.button("❌ Cancel", use_container_width=True):
            for key in st.session_state.keys():
                if key != "llm_cost":
                    st.session_state[key] = None if key != "awaiting_confirmation" else False
            st.rerun()
    st.markdown('</div>', unsafe_allow_html=True)

# Enhanced results display
if st.session_state.get("reviewed_sql"):
    st.markdown('<div class="container animate result-animation">', unsafe_allow_html=True)
    st.markdown("""
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <h2 style="margin: 0;">Query Results</h2>
        <div class="cost-display">${:.6f}</div>
    </div>
    """.format(st.session_state["llm_cost"]), unsafe_allow_html=True)
    
    # Enhanced results section
    if st.session_state.get("query_result"):
        st.markdown('<div class="badge success">✅ Query executed successfully</div>', unsafe_allow_html=True)
        
        # Display results - handle HTML tables for proper alignment
        try:
            if st.session_state["query_result"].startswith("<div class=\"sql-result-table\">"):
                # This is an HTML table, render it directly
                st.markdown(st.session_state["query_result"], unsafe_allow_html=True)
            else:
                # This is likely an error message or other text output
                st.code(st.session_state["query_result"])
        except Exception as e:
            st.error(f"Error displaying results: {e}")
            st.code(st.session_state["query_result"])
        
        st.download_button(
            "📥 Download Results",
            st.session_state["query_result"],
            "query_results.txt",
            "text/plain",
            key="download_results"
        )
    else:
        st.markdown('<div class="badge error">❌ Query failed compliance check</div>', unsafe_allow_html=True)
    
    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    
    # Enhanced tab layout
    tab1, tab2 = st.tabs(["📝 SQL Review", "🔒 Compliance Check"])
    
    with tab1:
        formatted_sql = sqlparse.format(st.session_state["reviewed_sql"], reindent=True, keyword_case='upper')
        st.code(formatted_sql, language="sql")
            
    with tab2:
        # Improved compliance detection logic
        is_compliant = False
        report_lines = st.session_state["compliance_report"].lower().splitlines()
        for line in report_lines[:3]:  # Check first few lines for verdict
            if "verdict:" in line and "compliant" in line and "issues found" not in line:
                is_compliant = True
                break
            if ("✓ compliant" in line or "✅ compliant" in line) and "issues found" not in line:
                is_compliant = True
                break
        
        # If the report explicitly mentions "issues found" in the verdict, it's not compliant
        for line in report_lines[:3]:
            if "verdict:" in line and "issues found" in line:
                is_compliant = False
                break
                
        if is_compliant:
            st.markdown("""
            <div style="display: flex; align-items: center; margin-bottom: 0.75rem;">
                <div class="badge success" style="margin-right: 0.75rem;">✅ Compliant</div>
                <span>This query passes all security and compliance checks</span>
            </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown("""
            <div style="display: flex; align-items: center; margin-bottom: 0.75rem;">
                <div class="badge warning" style="margin-right: 0.75rem;">⚠️ Issues found</div>
                <span>This query has potential security or compliance issues</span>
            </div>
            """, unsafe_allow_html=True)
        st.markdown(st.session_state["compliance_report"])
    
    st.markdown('<div class="divider"></div>', unsafe_allow_html=True)
    
    if st.button("🆕 New Query", type="primary"):
        # Store the current cost before resetting
        cost = st.session_state["llm_cost"]
        
        # Create a list of keys that should be reset but exclude widget keys
        keys_to_reset = [
            "generated_sql", 
            "reviewed_sql", 
            "compliance_report", 
            "query_result"
        ]
        
        # Reset specific session state values rather than iterating through all keys
        for key in keys_to_reset:
            if key in st.session_state:
                st.session_state[key] = None
                
        # Set boolean flags separately
        st.session_state["awaiting_confirmation"] = False
        st.session_state["regenerate_sql"] = False
        
        # Restore the cost
        st.session_state["llm_cost"] = cost
        
        # Trigger a rerun to refresh the UI
        st.rerun()
    
    st.markdown('</div>', unsafe_allow_html=True)

# Enhanced footer with version info and credits
st.markdown("""
<div class="footer">
    <div style="display: flex; justify-content: center; align-items: center; margin-bottom: 0.5rem;">
        <div style="width: 10px; height: 10px; background: linear-gradient(45deg, #4361ee, #4cc9f0); border-radius: 50%; margin-right: 0.5rem;"></div>
        <p style="margin: 0; font-weight: 500;">SQL Assistant Crew v2.0</p>
    </div>
    <p style="opacity: 0.7;">Powered by CrewAI + GPT-4o</p>
</div>
""", unsafe_allow_html=True)
