import sqlite3
import pandas as pd
import os

# Define path
DB_PATH = "data/healthcare_sample.sqlite"

def setup_sample_db():
    """Sets up a healthcare sample database with tables like patients, doctors, appointments, etc."""
    os.makedirs("data", exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Drop if exists
    cursor.executescript("""
        DROP TABLE IF EXISTS lab_results;
        DROP TABLE IF EXISTS prescriptions;
        DROP TABLE IF EXISTS appointments;
        DROP TABLE IF EXISTS doctors;
        DROP TABLE IF EXISTS patients;
    """)

    # Schema
    cursor.execute("""
        CREATE TABLE patients (
            patient_id INTEGER PRIMARY KEY,
            name TEXT,
            gender TEXT,
            birth_date TEXT,
            condition TEXT
        );
    """)
    cursor.execute("""
        CREATE TABLE doctors (
            doctor_id INTEGER PRIMARY KEY,
            name TEXT,
            specialty TEXT
        );
    """)
    cursor.execute("""
        CREATE TABLE appointments (
            appointment_id INTEGER PRIMARY KEY,
            patient_id INTEGER,
            doctor_id INTEGER,
            appointment_date TEXT,
            notes TEXT,
            FOREIGN KEY(patient_id) REFERENCES patients(patient_id),
            FOREIGN KEY(doctor_id) REFERENCES doctors(doctor_id)
        );
    """)
    cursor.execute("""
        CREATE TABLE prescriptions (
            prescription_id INTEGER PRIMARY KEY,
            patient_id INTEGER,
            doctor_id INTEGER,
            medication TEXT,
            dosage TEXT,
            date_prescribed TEXT,
            FOREIGN KEY(patient_id) REFERENCES patients(patient_id),
            FOREIGN KEY(doctor_id) REFERENCES doctors(doctor_id)
        );
    """)
    cursor.execute("""
        CREATE TABLE lab_results (
            result_id INTEGER PRIMARY KEY,
            patient_id INTEGER,
            test_name TEXT,
            result_value TEXT,
            test_date TEXT,
            FOREIGN KEY(patient_id) REFERENCES patients(patient_id)
        );
    """)

    # Sample Data
    cursor.executemany("INSERT INTO patients VALUES (?, ?, ?, ?, ?);", [
        (1, 'Alice Johnson', 'Female', '1985-06-01', 'Diabetes'),
        (2, 'Bob Smith', 'Male', '1978-12-12', 'Hypertension'),
        (3, 'Carol White', 'Female', '1990-04-22', 'Asthma'),
    ])
    cursor.executemany("INSERT INTO doctors VALUES (?, ?, ?);", [
        (1, 'Dr. Emily Clark', 'Cardiology'),
        (2, 'Dr. John Lee', 'Endocrinology'),
    ])
    cursor.executemany("INSERT INTO appointments VALUES (?, ?, ?, ?, ?);", [
        (1, 1, 2, '2024-03-10', 'Follow-up for diabetes check'),
        (2, 2, 1, '2024-03-12', 'Annual physical'),
        (3, 3, 1, '2024-04-01', 'Asthma evaluation'),
    ])
    cursor.executemany("INSERT INTO prescriptions VALUES (?, ?, ?, ?, ?, ?);", [
        (1, 1, 2, 'Metformin', '500mg twice daily', '2024-03-10'),
        (2, 2, 1, 'Lisinopril', '10mg daily', '2024-03-12'),
    ])
    cursor.executemany("INSERT INTO lab_results VALUES (?, ?, ?, ?, ?);", [
        (1, 1, 'HbA1c', '7.2%', '2024-03-05'),
        (2, 2, 'Cholesterol', '210 mg/dL', '2024-03-10'),
        (3, 3, 'Spirometry', 'Mild obstruction', '2024-03-25'),
    ])

    conn.commit()
    conn.close()
    print("✅ Healthcare sample DB created.")


def run_query(query):
    """Run SQL query and return results or error."""
    try:
        conn = sqlite3.connect(DB_PATH)
        df = pd.read_sql_query(query, conn)
        conn.close()
        return df.head().to_string(index=False)
    except Exception as e:
        return f"Query failed: {e}"


def get_db_schema(db_path=DB_PATH):
    """Returns raw CREATE statements of tables."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    schema = ""
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    for (table_name,) in cursor.fetchall():
        cursor.execute(f"SELECT sql FROM sqlite_master WHERE type='table' AND name='{table_name}';")
        schema += cursor.fetchone()[0] + ";\n\n"
    conn.close()
    return schema


def get_structured_schema(db_path=DB_PATH):
    """Returns a structured view of the DB schema for prompts."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    lines = ["Available tables and columns:"]
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    for (table_name,) in cursor.fetchall():
        cursor.execute(f"PRAGMA table_info({table_name})")
        columns = [row[1] for row in cursor.fetchall()]
        lines.append(f"- {table_name}: {', '.join(columns)}")
    conn.close()
    return '\n'.join(lines)


if __name__ == "__main__":
    setup_sample_db()
