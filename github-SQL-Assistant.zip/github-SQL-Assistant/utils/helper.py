import re

def extract_token_counts(token_usage_str):
    """
    Extract prompt and completion token counts from a string.
    Example input: 'token_usage=prompt_tokens=43, completion_tokens=97, total_tokens=140'
    """
    prompt = completion = 0
    prompt_match = re.search(r'prompt_tokens=(\d+)', token_usage_str)
    completion_match = re.search(r'completion_tokens=(\d+)', token_usage_str)
    if prompt_match:
        prompt = int(prompt_match.group(1))
    if completion_match:
        completion = int(completion_match.group(1))
    return prompt, completion

def calculate_gpt4o_cost(prompt_tokens, completion_tokens):
    """
    Calculate LLM cost for GPT-4o Mini (adjust these rates as needed).
    Pricing:
      - Prompt tokens: $0.0005 / 1K tokens
      - Completion tokens: $0.0015 / 1K tokens
    """
    input_cost = (prompt_tokens / 1000) * 0.00015
    output_cost = (completion_tokens / 1000) * 0.0006
    return input_cost + output_cost
