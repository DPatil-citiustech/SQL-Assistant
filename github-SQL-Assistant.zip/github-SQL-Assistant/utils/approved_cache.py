import json
import os

APPROVED_FILE = "data/approved_prompts.json"


def load_approved_prompts():
    """Loads approved prompts and their SQL queries from JSON file."""
    if not os.path.exists(APPROVED_FILE):
        return {}
    try:
        with open(APPROVED_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_approved_prompt(prompt, sql):
    """Saves a new prompt-SQL pair to the approved prompts file."""
    approved = load_approved_prompts()
    approved[prompt.strip()] = sql.strip()
    os.makedirs(os.path.dirname(APPROVED_FILE), exist_ok=True)
    with open(APPROVED_FILE, "w", encoding="utf-8") as f:
        json.dump(approved, f, indent=2)


def search_approved_prompts(search_term):
    """Searches approved prompts by a case-insensitive search term."""
    approved = load_approved_prompts()
    filtered = {
        prompt: sql
        for prompt, sql in approved.items()
        if search_term.lower() in prompt.lower()
    }
    return filtered
