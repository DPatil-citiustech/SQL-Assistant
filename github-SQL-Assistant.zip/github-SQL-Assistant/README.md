# 📘 SQL Assistant Crew

**SQL Assistant Crew** is a Streamlit-powered, CrewAI-orchestrated multi-agent assistant that allows users to interact with a **SQLite** database using natural language. With a modular agent architecture for generation, review, compliance, and execution, users can safely and intuitively run SQL queries—no manual SQL required. Checkout the blog for more details (https://towardsdatascience.com/a-multi-agent-sql-assistant-you-can-trust-with-human-in-loop-checkpoint-llm-cost-control/)

---

## 🧠 How It Works

This app uses a **CrewAI-based agent system** to process each user query through a collaborative pipeline:

1. **🗣 Natural Language Input (User)**  
   Users type their question in everyday language using the Streamlit front end.

2. **🤖 SQL Generation Agent**  
   Converts the user prompt into an SQL query using schema context and user intent.

3. **🔍 Query Review Agent**  
   Refines and optimizes the SQL query for correctness and performance.

4. **🔐 Compliance Agent**  
   Validates the SQL for data safety (e.g., prevents `DROP`, `DELETE`, `ALTER`, etc.)

5. **⚙️ Execution Agent**  
   Runs the approved SQL query against the SQLite database and returns results to the user.

6. **🔄 Schema Sync Agent**  
   Allows on-demand schema refresh so agents stay aware of the current database structure.

## 🔄 Complete User Flow Diagram

The diagram below illustrates the end-to-end flow from user input to results, including the human-in-the-loop approval steps:

```mermaid
flowchart TD

    %% --- INPUT & INITIATION ---

    A([User inputs natural language query])

    B([Load database schema])

    C([Initialize CrewAI agents])
 
    %% --- MAIN AGENT FLOW ---

    D([SQL Generator Agent<br>→ Generates SQL query])

    E{{Check Approved Cache<br>for identical prompt}}
 
    F([Display generated SQL to user])

    G{{User Decision:<br>Confirm / Try Again / Abort}}
 
    H([SQL Reviewer Agent<br>→ Optimize & clean SQL])

    I([Reset & regenerate SQL])

    J([Clear session<br>and cancel])

    K([Compliance Checker Agent<br>→ Validate against policy])

    L{{Compliant SQL?}}
 
    M([Execute SQL<br>via MCP Server])

    N([Block Execution<br>due to non-compliance])
 
    O([Display SQL results,<br>compliance report])

    P([Display reasons<br>for compliance failure])
 
    Q([Save prompt-SQL<br>to approved cache])

    R([User sees reason<br>why blocked])

    S([End Session])
 
    %% --- MCP Server Subgraph ---

    subgraph MCP_Server["MCP Server (Model Context Protocol)"]

      M1[query_sqlite tool]

      M2[Connect to SQLite DB]

      M3[Execute SQL securely]

      M4[Return formatted results]

    end
 
    %% --- FLOW CONNECTIONS ---

    A --> B --> C --> D --> E

    E -- "Cache hit" --> F

    E -- "Cache miss" --> F
 
    F --> G

    G -- "Confirm and Review" --> H --> K

    G -- "Try Again" --> I --> D

    G -- "Abort" --> J --> S
 
    K --> L

    L -- "Yes" --> M --> O --> Q --> S

    L -- "No" --> N --> P --> R --> S
 
    %% --- MCP Server Connections ---

    M --> M1 --> M2 --> M3 --> M4 --> O
```
 

### Key Human-in-the-Loop Features

1. **Approval Controls**: Users have explicit approval/rejection control before any SQL is executed
2. **Regeneration Option**: If the generated SQL doesn't match intent, users can request a new attempt
3. **Compliance Visibility**: Users see the compliance assessment before execution
4. **Cost Transparency**: LLM usage costs are displayed as users proceed
5. **Caching System**: Previously approved queries are saved, reducing costs for repeat queries

---

## ✅ Features

- 💬 Natural language SQL querying
- 🧠 Modular agents powered by [CrewAI](https://github.com/joaomdmoura/crewAI)
- 🖥️ Streamlit-based UI for accessibility
- 🗃️ Lightweight **SQLite** backend (ideal for local/dev environments)
- 🔄 One-click schema refresh support
- 🔐 Built-in query safety checks
- 📊 Clean result display and optional download

---

## 🛠 Tech Stack

| Component         | Technology          |
|-------------------|---------------------|
| Frontend UI       | Streamlit           |
| Database Engine   | SQLite              |
| Agent Framework   | [CrewAI](https://github.com/joaomdmoura/crewAI) |
| LLMs              | OpenAI / GPT-4 (via API) |
| Orchestration     | Python              |
| Schema Handling   | SQLite introspection |

---

## 🚀 Getting Started


