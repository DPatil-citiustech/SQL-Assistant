from crewai import Agent, Task, Crew, LLM
from pydantic import BaseModel, Field
import yaml
import os
import requests
from dotenv import load_dotenv



from crewai_tools import MCPServerAdapter
from mcp import StdioServerParameters

load_dotenv()

# Azure OpenAI LLM setup
azure_llm = LLM(
    model=f"azure/{os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME')}",
    api_base=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
)

# Load YAML configurations
files = {
    'agents': 'config/agents.yaml',
    'tasks': 'config/tasks.yaml',
}
configs = {}
for config_type, path in files.items():
    with open(path, 'r') as file:
        configs[config_type] = yaml.safe_load(file)

agents_config = configs['agents']
tasks_config = configs['tasks']

# Pydantic Models
class SQLQuery(BaseModel):
    sqlquery: str = Field(..., description="The raw SQL query")

class ReviewedSQLQuery(BaseModel):
    reviewed_sqlquery: str = Field(..., description="The reviewed SQL query")

class ComplianceReport(BaseModel):
    is_compliant: bool = Field(..., description="Whether the query is compliant with security policies")
    report: str = Field(..., description="The compliance analysis markdown")

class QueryResult(BaseModel):
    result: str = Field(..., description="SQL execution result via MCP")




# Start MCP server and get tools (using StdioServerParameters, matching database_agent.py)
server_params = StdioServerParameters(
    command="python",
    args=["sqlite_mcp_server.py"],
    env={**os.environ},
)
mcp_server_adapter = MCPServerAdapter(server_params)
mcp_server_adapter.__enter__()  # Start server (manual context entry)
mcp_tools = mcp_server_adapter.tools


# Agents
query_generator_agent = Agent(config=agents_config['query_generator_agent'], llm=azure_llm)
query_reviewer_agent = Agent(config=agents_config['query_reviewer_agent'], llm=azure_llm)
compliance_checker_agent = Agent(config=agents_config['compliance_checker_agent'], llm=azure_llm)

# Execution Agent with MCP tool(s) auto-discovered
execution_agent = Agent(
    config={
        "role": "SQL Executor",
        "goal": "Execute reviewed SQL queries safely via MCP server",
        "backstory": "You rely on an external MCP API to execute SQL; never run it locally.",
        "allow_delegation": False,
        "verbose": True,
        "temperature": 0.0
    },
    tools=mcp_tools,
    llm=azure_llm
)

# Tasks
query_task = Task(config=tasks_config['query_task'], agent=query_generator_agent, output_pydantic=SQLQuery)
review_task = Task(config=tasks_config['review_task'], agent=query_reviewer_agent, output_pydantic=ReviewedSQLQuery)
compliance_task = Task(config=tasks_config['compliance_task'], agent=compliance_checker_agent, context=[review_task], output_pydantic=ComplianceReport)

# Add execution task to tasks_config dynamically if not present
tasks_config['execution_task'] = {
    "description": "Execute this reviewed SQL using the MCP server: {reviewed_sqlquery}",
    "expected_output": "The query result from the MCP server or an error message."
}
execution_task = Task(config=tasks_config['execution_task'], agent=execution_agent, context=[review_task], output_pydantic=QueryResult)

# Crews
sql_generator_crew = Crew(agents=[query_generator_agent], tasks=[query_task], verbose=True)
sql_reviewer_crew = Crew(agents=[query_reviewer_agent], tasks=[review_task], verbose=True)
sql_compliance_crew = Crew(agents=[compliance_checker_agent], tasks=[compliance_task], verbose=True)
sql_executor_crew = Crew(agents=[execution_agent], tasks=[execution_task], verbose=True)
